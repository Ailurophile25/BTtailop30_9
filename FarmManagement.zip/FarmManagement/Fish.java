class Fish extends Animal{
    public Fish(){
        super();
    }

    public void move() {
        System.out.println("Fish can swim");
    }
}
