public class FarmManagement {
    public static void main(String[] args) {
        Animal p = new Pig();
        p.move();

        Animal d = new Duck();
        d.move();

        Animal f = new Fish();
        f.move();
    }
}
