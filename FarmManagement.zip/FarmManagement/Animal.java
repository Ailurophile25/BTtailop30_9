public class Animal {
    public void move() {
    }
}
