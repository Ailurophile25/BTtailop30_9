class Duck extends Animal {
    public Duck() {
        super();
    }

    public void move(){
        System.out.println("Duck can swim and walk");
    }
}
