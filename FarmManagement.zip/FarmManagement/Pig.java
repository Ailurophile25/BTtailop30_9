class Pig extends Animal{
    public Pig(){
        super();
    }

    public void move() {
        System.out.println("Pig can walk");
    }
}
