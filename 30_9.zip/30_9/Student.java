public class Student {
    private String name, msv;
    private int date;

    public String getName() {
        return name;

    }
    public void setName(String name) {
        this.name = name;
    }

    public int getDate() {
        return date;
    }

    public void setDate(int date) {
        this.date = date;
    }

    public String getMsv() {
        return msv;
    }

    public void setMsv(String msv) {
        this.msv = msv;
    }

    public Student(String name, int date, String msv) {
        this.name = name;
        this.date = date;
        this.msv = msv;
    }

    public Student(Student s) {
        this.name = s.name;
        this.date = s.date;
        this.msv = s.msv;
    }
}
